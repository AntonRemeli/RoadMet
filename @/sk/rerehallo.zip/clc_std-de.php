<?
error_reporting(0);	


//--------------- STANDARD  Data to Web Variables   START


	
  	$st_upc[$stNo]  ="#BDBA7D"; 	// Default values for RoadSurfaceCondition
	if ($st_upn[$stNo]==4) {$st_upa[$stNo]="z�plava"; $st_upc[$stNo]="#6666ff";}
	if ($st_upn[$stNo]==3) {$st_upa[$stNo]="vlhko"; $st_upc[$stNo]="#42A0FF";}
	if ($st_upn[$stNo]==2.5) {$st_upa[$stNo]="soln� vlhkos�"; $st_upc[$stNo]="#99CCFF";}
	if ($st_upn[$stNo]==2) {$st_upa[$stNo]="mokro"; $st_upc[$stNo]="#99CCFF";}
	if ($st_upn[$stNo]==1.5) {$st_upa[$stNo]="vlhko"; $st_upc[$stNo]="#99CCFF";}
	if ($st_upn[$stNo]==1) {$st_upa[$stNo]="sucho"; $st_upc[$stNo]="#FDF8BB";}
	if ($st_upn[$stNo]==-1) {$st_upa[$stNo]="podchladeno"; $st_upc[$stNo]="#ff8888";}
	if ($st_upn[$stNo]==-1.5) {$st_upa[$stNo]="�myk�avo"; $st_upc[$stNo]="#ff8888";}
	if ($st_upn[$stNo]==-2) {$st_upa[$stNo]="klzko"; $st_upc[$stNo]="#ff5555";}
	if ($st_upn[$stNo]==-2.5) {$st_upa[$stNo]="soln� klzkos�"; $st_upc[$stNo]="#ff5555";}
	if ($st_upn[$stNo]==-3) {$st_upa[$stNo]="po�adovica"; $st_upc[$stNo]="#ff2222";}
	if ($st_upn[$stNo]==-4) {$st_upa[$stNo]="sneh"; $st_upc[$stNo]="#ffffff";}

 	$st_rain[$stNo]=$st_rain[$stNo]*(1+$st_wdt[$stNo]);

	$st_cst[$stNo] = "--";
	$dh=0.05;
	if ($st_csn[$stNo]==3)      $st_cst[$stNo] = "D��";
	if ($st_csn[$stNo]==2)      $st_cst[$stNo] = "Hmla";
	if ($st_csn[$stNo]==1)      $st_cst[$stNo] = "Topenie";
	if ($st_csn[$stNo]==0)      $st_cst[$stNo] = "--";
	if ($st_csn[$stNo]==-1)     $st_cst[$stNo] = "N�mraza";
  if ($st_csn[$stNo]==-2)     $st_cst[$stNo] = "D�� so snehom";
  if ($st_csn[$stNo]==-2.5)     $st_cst[$stNo] = "Kr�py";
  if ($st_csn[$stNo]==-3)     $st_cst[$stNo] = "Sneh";

 $Pta_Hpt="Rel/Ros:";  //%rel.Feuchte/Taupunkt
 $Lh�_Uh�="Tvz/Tce:";  //Lufttemp./Fahrbahntemp.
 $Th�_Fpt="HlT/Bmr:";  //Tieftemp./Gefrierpunkt
 $Vt�_Up�="Chf/Sce:";  //Chem.Faktor/Stra�enzustand
 $T�p_Vrv="Nap/Vfi:";  //Spannung/Wasserfilm
 $Csi_Cst="InZ/Nst:";  //Niederschlagsintensit�t/Niederschlagtyp


  
  if ($vi7[$stNo]==-1)
  {
 $Pta_Hpt="Rel/Ros:";
 $Lh�_Uh�="Tvz/Tce:";
 $Th�_Fpt="R�v/V�v:";   //R�chlos� vetra/V��ka vetra
 $Vt�_Up�="Smervet:";   //Smer vetra
 $T�p_Vrv="Min/Max:";
 $Csi_Cst="Vidite�:";   //Vidite�nos�
 
 $sx_surfdt[$stNo]=$vi2[$stNo]/10;
 $st_fpt[$stNo]=$vi3[$stNo]/10;
 $st_ssalt[$stNo]=$vi4[$stNo]*10;
 $st_upa[$stNo]="(Stupe�)";
 $st_AccV[$stNo]=$vi5[$stNo]*10;
 $st_wdt[$stNo]=$vi6[$stNo]*10;
 $st_rain[$stNo]=$vi1[$stNo]*100;
 $st_cst[$stNo]="Meter";
 
 if($st_rain[$stNo]<10.0) $st_rain[$stNo]="---";
  }




//--------------- STANDARD  Data to Web Variables   END


?>
